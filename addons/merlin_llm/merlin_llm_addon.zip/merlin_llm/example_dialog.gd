extends Control
## Exemple de scène de dialogue avec Merlin
## À utiliser comme référence pour intégrer MerlinAI dans ton jeu

# === RÉFÉRENCES UI ===
@onready var input_field: LineEdit = $VBoxContainer/InputContainer/InputField
@onready var send_button: Button = $VBoxContainer/InputContainer/SendButton
@onready var response_label: RichTextLabel = $VBoxContainer/ResponsePanel/ResponseLabel
@onready var status_label: Label = $VBoxContainer/StatusBar/StatusLabel
@onready var action_log: RichTextLabel = $VBoxContainer/ActionPanel/ActionLog

# === ÉTAT ===
var is_waiting: bool = false

func _ready():
	# Connecter les signaux de MerlinAI
	if MerlinAI:
		MerlinAI.response_received.connect(_on_merlin_response)
		MerlinAI.action_executed.connect(_on_action_executed)
		MerlinAI.error_occurred.connect(_on_error)
		MerlinAI.server_status_changed.connect(_on_server_status)
		
		# Vérifier le statut initial
		_update_server_status(MerlinAI.is_server_connected)
	else:
		status_label.text = "⚠️ MerlinAI non chargé - Activer le plugin !"
		status_label.modulate = Color.RED
	
	# Connecter les événements UI
	input_field.text_submitted.connect(_on_input_submitted)
	send_button.pressed.connect(_on_send_pressed)
	
	# Focus sur l'input
	input_field.grab_focus()
	
	# Message d'accueil
	response_label.text = "[i]Merlin apparaît dans un nuage de fumée mystique...[/i]\n\n\"Bienvenue, jeune aventurier ! Je suis Merlin, le sage des âges. Que puis-je faire pour toi aujourd'hui ?\""

func _on_input_submitted(text: String):
	_send_message(text)

func _on_send_pressed():
	_send_message(input_field.text)

func _send_message(text: String):
	if text.strip_edges().is_empty():
		return
	
	if is_waiting:
		return
	
	if not MerlinAI or not MerlinAI.is_server_connected:
		_show_error("Serveur LLM non connecté !")
		return
	
	# Préparer l'UI
	is_waiting = true
	input_field.editable = false
	send_button.disabled = true
	response_label.text = "[i]Merlin réfléchit, sa barbe scintille de magie...[/i]"
	status_label.text = "⏳ Génération en cours..."
	
	# Envoyer au LLM
	MerlinAI.process_player_input(text)
	
	# Vider l'input
	input_field.clear()

func _on_merlin_response(result: Dictionary):
	is_waiting = false
	input_field.editable = true
	send_button.disabled = false
	status_label.text = "✅ Connecté"
	
	# Afficher la réponse
	var response_text = result.get("response", "...")
	response_label.text = "[b]Merlin :[/b]\n\n" + response_text
	
	# Vérifier s'il y a des erreurs d'action
	if result.has("action_errors") and not result.action_errors.is_empty():
		response_label.text += "\n\n[color=orange][i](Action impossible: " + ", ".join(result.action_errors) + ")[/i][/color]"
	
	# Focus sur l'input
	input_field.grab_focus()

func _on_action_executed(action: Dictionary):
	var action_type = action.get("type", "UNKNOWN")
	var params = action.get("params", {})
	
	var log_text = "[color=green]► Action: %s[/color]" % action_type
	if not params.is_empty():
		log_text += "\n   Params: %s" % str(params)
	
	action_log.text = log_text + "\n\n" + action_log.text
	
	# Limiter la taille du log
	if action_log.text.length() > 2000:
		action_log.text = action_log.text.substr(0, 2000)

func _on_error(message: String):
	is_waiting = false
	input_field.editable = true
	send_button.disabled = false
	
	_show_error(message)

func _show_error(message: String):
	response_label.text = "[color=red][b]Erreur :[/b] " + message + "[/color]"
	status_label.text = "❌ Erreur"

func _on_server_status(is_connected: bool):
	_update_server_status(is_connected)

func _update_server_status(is_connected: bool):
	if is_connected:
		status_label.text = "✅ Connecté"
		status_label.modulate = Color.GREEN
		input_field.editable = true
		send_button.disabled = false
	else:
		status_label.text = "❌ Serveur déconnecté"
		status_label.modulate = Color.RED
		input_field.editable = false
		send_button.disabled = true

# === FONCTIONS UTILITAIRES ===

func update_game_state_example():
	"""Exemple de mise à jour de l'état du jeu"""
	if MerlinAI:
		MerlinAI.update_game_state("player_name", "Aldric")
		MerlinAI.update_game_state("player_level", 5)
		MerlinAI.update_game_state("current_location", "foret_enchantee")
		MerlinAI.update_game_state("player_health", 80)
		MerlinAI.update_game_state("player_mana", 30)
		MerlinAI.update_game_state("known_spells", ["fireball", "heal"])
		MerlinAI.update_game_state("inventory", {"potion_sante": 3, "herbes_guerison": 5})
		MerlinAI.update_game_state("active_quests", ["quete_cristal"])
		MerlinAI.update_game_state("available_quests", ["quete_foret"])

func reconnect_server():
	"""Tente de reconnecter au serveur"""
	if MerlinAI:
		status_label.text = "🔄 Reconnexion..."
		MerlinAI.check_server_connection()
