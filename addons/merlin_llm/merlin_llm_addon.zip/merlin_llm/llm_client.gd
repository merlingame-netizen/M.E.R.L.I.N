extends Node
class_name LLMClient
## Client HTTP pour communiquer avec le serveur llama.cpp

signal request_completed(response: String)
signal request_failed(error: String)

# Configuration par défaut
var default_temperature: float = 0.7
var default_max_tokens: int = 256
var timeout_seconds: float = 120.0

# Pool de HTTPRequest pour requêtes parallèles
var http_pool: Array[HTTPRequest] = []
var pool_size: int = 3

func _ready():
	# Créer le pool de requêtes HTTP
	for i in range(pool_size):
		var http = HTTPRequest.new()
		http.timeout = timeout_seconds
		add_child(http)
		http_pool.append(http)

# === MÉTHODE PRINCIPALE ASYNC ===

func complete_async(server_url: String, prompt: String, max_tokens: int = 256, temperature: float = 0.7) -> String:
	"""Envoie une requête de complétion et attend la réponse"""
	var http = _get_available_http()
	if http == null:
		push_error("[LLMClient] Pas de HTTPRequest disponible")
		return ""
	
	var body = {
		"prompt": prompt,
		"n_predict": max_tokens,
		"temperature": temperature,
		"stop": ["</s>", "<|im_end|>", "<|eot_id|>", "<|end|>"],
		"stream": false,
		"cache_prompt": true
	}
	
	var headers = ["Content-Type: application/json"]
	var url = server_url.trim_suffix("/") + "/completion"
	
	var error = http.request(url, headers, HTTPClient.METHOD_POST, JSON.stringify(body))
	
	if error != OK:
		push_error("[LLMClient] Erreur requête HTTP: ", error)
		request_failed.emit("HTTP request error: " + str(error))
		return ""
	
	# Attendre la réponse
	var result = await http.request_completed
	
	var response_code = result[1]
	var response_body = result[3] as PackedByteArray
	
	if response_code != 200:
		var error_msg = "HTTP error: " + str(response_code)
		push_error("[LLMClient] ", error_msg)
		request_failed.emit(error_msg)
		return ""
	
	var json_str = response_body.get_string_from_utf8()
	var json = JSON.parse_string(json_str)
	
	if json == null:
		push_error("[LLMClient] Réponse JSON invalide")
		request_failed.emit("Invalid JSON response")
		return ""
	
	var content = json.get("content", "")
	request_completed.emit(content)
	return content

# === VÉRIFICATION SANTÉ SERVEUR ===

func check_health(server_url: String) -> bool:
	"""Vérifie si le serveur est accessible"""
	var http = HTTPRequest.new()
	http.timeout = 5.0
	add_child(http)
	
	var url = server_url.trim_suffix("/") + "/health"
	var error = http.request(url, [], HTTPClient.METHOD_GET)
	
	if error != OK:
		http.queue_free()
		return false
	
	var result = await http.request_completed
	http.queue_free()
	
	var response_code = result[1]
	return response_code == 200

# === COMPLÉTION AVEC CALLBACK ===

func complete_with_callback(server_url: String, prompt: String, callback: Callable, max_tokens: int = 256, temperature: float = 0.7) -> void:
	"""Version avec callback au lieu de await"""
	var response = await complete_async(server_url, prompt, max_tokens, temperature)
	callback.call(response)

# === STREAMING (pour réponses progressives) ===

func complete_streaming(server_url: String, prompt: String, on_token: Callable, max_tokens: int = 256) -> String:
	"""Complétion en streaming - appelle on_token pour chaque token reçu"""
	# Note: llama.cpp supporte le streaming via Server-Sent Events
	# Pour simplifier, on utilise ici une requête normale
	# TODO: Implémenter le vrai streaming SSE si nécessaire
	
	var full_response = await complete_async(server_url, prompt, max_tokens)
	
	# Simuler le streaming en découpant la réponse
	var words = full_response.split(" ")
	var accumulated = ""
	for word in words:
		accumulated += word + " "
		on_token.call(word + " ", accumulated.strip_edges())
		await get_tree().create_timer(0.02).timeout
	
	return full_response

# === CHAT COMPLETION (format messages) ===

func chat_completion(server_url: String, messages: Array, max_tokens: int = 256) -> String:
	"""Complétion au format chat (liste de messages)"""
	# Construire le prompt à partir des messages
	var prompt = ""
	
	for msg in messages:
		var role = msg.get("role", "user")
		var content = msg.get("content", "")
		
		match role:
			"system":
				prompt += "<|im_start|>system\n" + content + "<|im_end|>\n"
			"user":
				prompt += "<|im_start|>user\n" + content + "<|im_end|>\n"
			"assistant":
				prompt += "<|im_start|>assistant\n" + content + "<|im_end|>\n"
	
	# Ajouter le début de la réponse assistant
	prompt += "<|im_start|>assistant\n"
	
	return await complete_async(server_url, prompt, max_tokens)

# === UTILITAIRES INTERNES ===

func _get_available_http() -> HTTPRequest:
	"""Récupère une HTTPRequest disponible du pool"""
	for http in http_pool:
		if http.get_http_client_status() == HTTPClient.STATUS_DISCONNECTED:
			return http
	
	# Toutes occupées, en créer une nouvelle temporairement
	var http = HTTPRequest.new()
	http.timeout = timeout_seconds
	add_child(http)
	
	# La supprimer après utilisation
	http.request_completed.connect(func(_r, _c, _h, _b): 
		await get_tree().create_timer(1.0).timeout
		if is_instance_valid(http):
			http.queue_free()
	, CONNECT_ONE_SHOT)
	
	return http

# === CONFIGURATION ===

func set_timeout(seconds: float) -> void:
	timeout_seconds = seconds
	for http in http_pool:
		http.timeout = seconds

func set_default_temperature(temp: float) -> void:
	default_temperature = clamp(temp, 0.0, 2.0)

func set_default_max_tokens(tokens: int) -> void:
	default_max_tokens = max(1, tokens)
