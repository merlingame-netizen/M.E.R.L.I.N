extends Node
class_name GameStateSync
## Synchronisation entre l'état réel du jeu et le sandbox du LLM
## Applique les actions validées sur l'état du jeu

signal state_changed(key: String, old_value: Variant, new_value: Variant)
signal action_applied(action: Dictionary, changes: Dictionary)
signal action_rejected(action: Dictionary, reason: String)

# État réel du jeu (source de vérité)
var game_state: Dictionary = {}

# Callbacks pour les actions (connectés par le jeu)
var action_handlers: Dictionary = {}

# Historique des changements (pour undo si nécessaire)
var change_history: Array = []
const MAX_HISTORY: int = 50

func _ready():
	_init_default_state()

func _init_default_state():
	"""Initialise l'état par défaut"""
	game_state = {
		# Joueur
		"player_name": "Aventurier",
		"player_level": 1,
		"player_health": 100,
		"player_max_health": 100,
		"player_mana": 50,
		"player_max_mana": 50,
		"player_xp": 0,
		
		# Position
		"current_location": "foret_ancienne",
		"discovered_locations": ["foret_ancienne"],
		
		# Inventaire
		"inventory": {},
		"gold": 0,
		"equipped_weapon": null,
		"equipped_armor": null,
		
		# Magie
		"known_spells": [],
		
		# Quêtes
		"available_quests": [],
		"active_quests": [],
		"completed_quests": [],
		"quest_progress": {},
		
		# Combat
		"targets_in_range": [],
		"enemies_nearby": [],
		
		# Informations débloquées
		"unlocked_info": [],
		
		# Événements
		"available_events": [],
		"triggered_events": [],
		
		# Marqueurs carte
		"map_markers": []
	}

# === ACCÈS À L'ÉTAT ===

func get_state() -> Dictionary:
	"""Retourne une copie de l'état actuel"""
	return game_state.duplicate(true)

func get_value(key: String, default: Variant = null) -> Variant:
	"""Récupère une valeur de l'état"""
	return game_state.get(key, default)

func update_state(key: String, value: Variant):
	"""Met à jour une valeur de l'état"""
	var old_value = game_state.get(key)
	game_state[key] = value
	
	_record_change(key, old_value, value)
	state_changed.emit(key, old_value, value)

func update_state_bulk(updates: Dictionary):
	"""Met à jour plusieurs valeurs"""
	for key in updates:
		update_state(key, updates[key])

# === APPLICATION DES ACTIONS ===

func apply_action(action: Dictionary) -> bool:
	"""Applique une action validée sur l'état du jeu"""
	var action_type = action.get("type", "")
	var params = action.get("params", {})
	
	# Vérifier si un handler personnalisé existe
	if action_handlers.has(action_type):
		var result = action_handlers[action_type].call(action, game_state)
		if result is Dictionary:
			action_applied.emit(action, result)
			return true
		return false
	
	# Sinon utiliser les handlers par défaut
	var changes = _apply_default_action(action_type, params)
	
	if changes.is_empty():
		action_rejected.emit(action, "Aucun handler pour: " + action_type)
		return false
	
	action_applied.emit(action, changes)
	return true

func _apply_default_action(action_type: String, params: Dictionary) -> Dictionary:
	"""Applique une action avec les handlers par défaut"""
	var changes: Dictionary = {}
	
	match action_type:
		# === COMBAT ===
		"ATTACK_MELEE":
			# Le jeu doit gérer les dégâts réels
			changes["combat_action"] = "melee_attack"
			changes["target"] = params.get("target_id", "")
		
		"CAST_DAMAGE_SPELL":
			var spell_id = params.get("spell_id", "")
			var mana_cost = _get_spell_mana_cost(spell_id)
			var new_mana = max(0, game_state.player_mana - mana_cost)
			update_state("player_mana", new_mana)
			changes["mana_spent"] = mana_cost
			changes["spell_cast"] = spell_id
			changes["target"] = params.get("target_id", "")
		
		"DEFEND":
			changes["combat_action"] = "defend"
		
		# === DIALOGUE ===
		"REVEAL_INFO":
			var info_id = params.get("info_id", "")
			if info_id and info_id not in game_state.unlocked_info:
				var unlocked = game_state.unlocked_info.duplicate()
				unlocked.append(info_id)
				update_state("unlocked_info", unlocked)
				changes["info_revealed"] = info_id
		
		"GIVE_QUEST":
			var quest_id = params.get("quest_id", "")
			if quest_id and quest_id not in game_state.active_quests:
				var active = game_state.active_quests.duplicate()
				active.append(quest_id)
				update_state("active_quests", active)
				
				# Retirer des disponibles
				var available = game_state.available_quests.duplicate()
				available.erase(quest_id)
				update_state("available_quests", available)
				
				changes["quest_started"] = quest_id
		
		"TRADE_OFFER":
			changes["trade_offer"] = {
				"offered": params.get("item_offered", ""),
				"requested": params.get("item_requested", "")
			}
		
		# === EXPLORATION ===
		"REVEAL_PATH":
			var path_id = params.get("path_id", "")
			changes["path_revealed"] = path_id
		
		"MARK_LOCATION":
			var location_id = params.get("location_id", "")
			if location_id:
				var markers = game_state.map_markers.duplicate()
				if location_id not in markers:
					markers.append(location_id)
					update_state("map_markers", markers)
				changes["location_marked"] = location_id
		
		"TRIGGER_EVENT":
			var event_id = params.get("event_id", "")
			if event_id and event_id not in game_state.triggered_events:
				var triggered = game_state.triggered_events.duplicate()
				triggered.append(event_id)
				update_state("triggered_events", triggered)
				changes["event_triggered"] = event_id
		
		# === INVENTAIRE ===
		"GIVE_ITEM":
			var item_id = params.get("item_id", "")
			var quantity = params.get("quantity", 1)
			if item_id:
				var inventory = game_state.inventory.duplicate()
				inventory[item_id] = inventory.get(item_id, 0) + quantity
				update_state("inventory", inventory)
				changes["item_received"] = {"id": item_id, "quantity": quantity}
		
		"TAKE_ITEM":
			var item_id = params.get("item_id", "")
			var quantity = params.get("quantity", 1)
			if item_id:
				var inventory = game_state.inventory.duplicate()
				if inventory.has(item_id):
					inventory[item_id] = max(0, inventory[item_id] - quantity)
					if inventory[item_id] <= 0:
						inventory.erase(item_id)
					update_state("inventory", inventory)
					changes["item_taken"] = {"id": item_id, "quantity": quantity}
		
		# === MAGIE ===
		"TEACH_SPELL":
			var spell_id = params.get("spell_id", "")
			if spell_id and spell_id not in game_state.known_spells:
				var spells = game_state.known_spells.duplicate()
				spells.append(spell_id)
				update_state("known_spells", spells)
				changes["spell_learned"] = spell_id
		
		"ENCHANT_ITEM":
			var item_id = params.get("item_id", "")
			var enchant_type = params.get("enchant_type", "")
			changes["item_enchanted"] = {"id": item_id, "enchant": enchant_type}
		
		"SUMMON_CREATURE":
			var creature_id = params.get("creature_id", "")
			var location = params.get("location", "")
			changes["creature_summoned"] = {"id": creature_id, "location": location}
		
		# === QUÊTES ===
		"START_QUEST":
			var quest_id = params.get("quest_id", "")
			if quest_id and quest_id not in game_state.active_quests:
				var active = game_state.active_quests.duplicate()
				active.append(quest_id)
				update_state("active_quests", active)
				changes["quest_started"] = quest_id
		
		"UPDATE_QUEST":
			var quest_id = params.get("quest_id", "")
			var step = params.get("step", "")
			if quest_id:
				var progress = game_state.quest_progress.duplicate()
				if not progress.has(quest_id):
					progress[quest_id] = {}
				progress[quest_id]["current_step"] = step
				update_state("quest_progress", progress)
				changes["quest_updated"] = {"id": quest_id, "step": step}
		
		"COMPLETE_QUEST":
			var quest_id = params.get("quest_id", "")
			if quest_id:
				# Retirer des actives
				var active = game_state.active_quests.duplicate()
				active.erase(quest_id)
				update_state("active_quests", active)
				
				# Ajouter aux complétées
				var completed = game_state.completed_quests.duplicate()
				if quest_id not in completed:
					completed.append(quest_id)
				update_state("completed_quests", completed)
				
				changes["quest_completed"] = quest_id
	
	return changes

func _get_spell_mana_cost(spell_id: String) -> int:
	"""Retourne le coût en mana d'un sort"""
	# TODO: Charger depuis une config
	var spell_costs = {
		"fireball": 20,
		"heal": 15,
		"shield": 10,
		"lightning": 25,
		"reveal_path": 5
	}
	return spell_costs.get(spell_id, 10)

# === HANDLERS PERSONNALISÉS ===

func register_action_handler(action_type: String, handler: Callable):
	"""Enregistre un handler personnalisé pour un type d'action
	Le handler reçoit (action: Dictionary, game_state: Dictionary) -> Dictionary (changes)"""
	action_handlers[action_type] = handler

func unregister_action_handler(action_type: String):
	"""Supprime un handler personnalisé"""
	action_handlers.erase(action_type)

# === HISTORIQUE ===

func _record_change(key: String, old_value: Variant, new_value: Variant):
	"""Enregistre un changement dans l'historique"""
	change_history.append({
		"timestamp": Time.get_unix_time_from_system(),
		"key": key,
		"old_value": old_value,
		"new_value": new_value
	})
	
	while change_history.size() > MAX_HISTORY:
		change_history.pop_front()

func undo_last_change() -> bool:
	"""Annule le dernier changement"""
	if change_history.is_empty():
		return false
	
	var last_change = change_history.pop_back()
	game_state[last_change.key] = last_change.old_value
	state_changed.emit(last_change.key, last_change.new_value, last_change.old_value)
	return true

# === SAUVEGARDE / CHARGEMENT ===

func save_state(path: String) -> bool:
	"""Sauvegarde l'état dans un fichier"""
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(game_state, "\t"))
		file.close()
		return true
	return false

func load_state(path: String) -> bool:
	"""Charge l'état depuis un fichier"""
	if not FileAccess.file_exists(path):
		return false
	
	var file = FileAccess.open(path, FileAccess.READ)
	var data = JSON.parse_string(file.get_as_text())
	file.close()
	
	if data is Dictionary:
		game_state = data
		return true
	return false

func reset_state():
	"""Réinitialise l'état à ses valeurs par défaut"""
	_init_default_state()
	change_history.clear()
