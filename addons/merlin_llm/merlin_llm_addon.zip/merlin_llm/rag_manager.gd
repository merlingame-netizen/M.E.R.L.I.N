extends Node
class_name RAGManager
## Gestionnaire RAG (Retrieval-Augmented Generation)
## Gère l'historique des conversations et le contexte du monde

# Chemins de sauvegarde
const SAVE_DIR = "user://merlin_ai/"
const HISTORY_PATH = SAVE_DIR + "history.json"
const WORLD_STATE_PATH = SAVE_DIR + "world_state.json"
const EVENTS_PATH = SAVE_DIR + "events.json"

# Configuration
const MAX_HISTORY_ITEMS: int = 100
const MAX_EVENTS: int = 200
const RELEVANCE_THRESHOLD: float = 0.3

# Données
var history: Array = []
var world_state: Dictionary = {}
var events: Array = []
var actions_by_category: Dictionary = {}

# Index pour recherche rapide
var history_index: Dictionary = {}  # mot -> [indices]

func _ready():
	_ensure_save_dir()
	_load_all_data()

func _ensure_save_dir():
	if not DirAccess.dir_exists_absolute(SAVE_DIR.replace("user://", OS.get_user_data_dir() + "/")):
		DirAccess.make_dir_recursive_absolute(SAVE_DIR.replace("user://", OS.get_user_data_dir() + "/"))

# === CHARGEMENT / SAUVEGARDE ===

func _load_all_data():
	_load_history()
	_load_world_state()
	_load_events()

func _load_history():
	if FileAccess.file_exists(HISTORY_PATH):
		var file = FileAccess.open(HISTORY_PATH, FileAccess.READ)
		var data = JSON.parse_string(file.get_as_text())
		file.close()
		if data is Array:
			history = data
			_rebuild_history_index()
			print("[RAGManager] Historique chargé: ", history.size(), " entrées")

func _load_world_state():
	if FileAccess.file_exists(WORLD_STATE_PATH):
		var file = FileAccess.open(WORLD_STATE_PATH, FileAccess.READ)
		var data = JSON.parse_string(file.get_as_text())
		file.close()
		if data is Dictionary:
			world_state = data
			print("[RAGManager] État du monde chargé")

func _load_events():
	if FileAccess.file_exists(EVENTS_PATH):
		var file = FileAccess.open(EVENTS_PATH, FileAccess.READ)
		var data = JSON.parse_string(file.get_as_text())
		file.close()
		if data is Array:
			events = data
			print("[RAGManager] Événements chargés: ", events.size())

func _save_history():
	var file = FileAccess.open(HISTORY_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(history, "\t"))
	file.close()

func _save_world_state():
	var file = FileAccess.open(WORLD_STATE_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(world_state, "\t"))
	file.close()

func _save_events():
	var file = FileAccess.open(EVENTS_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(events, "\t"))
	file.close()

# === RÉCUPÉRATION DE CONTEXTE ===

func get_relevant_context(query: String, category: String) -> Dictionary:
	"""Récupère le contexte pertinent pour une requête"""
	return {
		"recent_history": _get_recent_history(5),
		"relevant_history": _search_history(query, 3),
		"world_state_subset": _get_relevant_state(query, category),
		"recent_events": _get_recent_events(5),
		"available_actions": get_actions_for_category(category)
	}

func _get_recent_history(count: int) -> Array:
	"""Retourne les N dernières entrées de l'historique"""
	if history.size() <= count:
		return history.duplicate()
	return history.slice(-count)

func _search_history(query: String, count: int) -> Array:
	"""Recherche les entrées d'historique les plus pertinentes"""
	var keywords = _extract_keywords(query)
	var scored: Array = []
	
	for i in range(history.size()):
		var item = history[i]
		var score = _calculate_relevance(item, keywords)
		if score > RELEVANCE_THRESHOLD:
			scored.append({"item": item, "score": score, "index": i})
	
	# Trier par score décroissant
	scored.sort_custom(func(a, b): return a.score > b.score)
	
	# Retourner les meilleurs résultats
	var results: Array = []
	for i in range(min(count, scored.size())):
		results.append(scored[i].item)
	
	return results

func _extract_keywords(text: String) -> Array:
	"""Extrait les mots-clés significatifs d'un texte"""
	var words = text.to_lower().split(" ")
	var keywords: Array = []
	
	# Mots à ignorer (stop words français)
	var stop_words = ["le", "la", "les", "un", "une", "des", "de", "du", "et", "ou", "mais", "donc", "car", "ni", "que", "qui", "quoi", "est", "sont", "a", "ont", "je", "tu", "il", "elle", "nous", "vous", "ils", "elles", "ce", "cette", "ces", "mon", "ma", "mes", "ton", "ta", "tes", "son", "sa", "ses", "pour", "dans", "sur", "avec", "sans", "par", "en", "au", "aux"]
	
	for word in words:
		var cleaned = word.strip_edges()
		if cleaned.length() > 2 and cleaned not in stop_words:
			keywords.append(cleaned)
	
	return keywords

func _calculate_relevance(item: Dictionary, keywords: Array) -> float:
	"""Calcule un score de pertinence pour un item"""
	var text = (item.get("input", "") + " " + item.get("response", "")).to_lower()
	var matches = 0
	
	for kw in keywords:
		if text.contains(kw):
			matches += 1
	
	if keywords.size() == 0:
		return 0.0
	
	return float(matches) / float(keywords.size())

func _get_relevant_state(query: String, category: String) -> Dictionary:
	"""Retourne les parties pertinentes de l'état du monde"""
	var relevant: Dictionary = {}
	
	# Toujours inclure certaines infos de base
	var always_include = ["player_name", "player_level", "current_location", "active_quests"]
	for key in always_include:
		if world_state.has(key):
			relevant[key] = world_state[key]
	
	# Inclure selon la catégorie
	match category:
		"combat":
			for key in ["player_health", "player_mana", "equipped_weapon", "known_spells", "enemies_nearby"]:
				if world_state.has(key):
					relevant[key] = world_state[key]
		"inventaire":
			if world_state.has("inventory"):
				relevant["inventory"] = world_state["inventory"]
			if world_state.has("gold"):
				relevant["gold"] = world_state["gold"]
		"magie":
			for key in ["player_mana", "known_spells", "spell_ingredients"]:
				if world_state.has(key):
					relevant[key] = world_state[key]
		"quete":
			if world_state.has("quests"):
				relevant["quests"] = world_state["quests"]
			if world_state.has("completed_quests"):
				relevant["completed_quests"] = world_state["completed_quests"]
		"exploration":
			for key in ["current_location", "discovered_locations", "map_markers"]:
				if world_state.has(key):
					relevant[key] = world_state[key]
	
	return relevant

func _get_recent_events(count: int) -> Array:
	"""Retourne les N derniers événements"""
	if events.size() <= count:
		return events.duplicate()
	return events.slice(-count)

# === ACTIONS PAR CATÉGORIE ===

func set_actions_by_category(categories_config: Dictionary):
	"""Configure les actions disponibles par catégorie"""
	actions_by_category = categories_config

func get_actions_for_category(category: String) -> Dictionary:
	"""Retourne les actions disponibles pour une catégorie"""
	if actions_by_category.has(category):
		return actions_by_category[category]
	return {}

# === AJOUT DE DONNÉES ===

func add_to_history(input_text: String, response: String):
	"""Ajoute une entrée à l'historique"""
	var entry = {
		"timestamp": Time.get_unix_time_from_system(),
		"datetime": Time.get_datetime_string_from_system(),
		"input": input_text,
		"response": response
	}
	
	history.append(entry)
	_index_history_entry(entry, history.size() - 1)
	
	# Limiter la taille
	while history.size() > MAX_HISTORY_ITEMS:
		history.pop_front()
		_rebuild_history_index()
	
	_save_history()

func add_event(event_type: String, data: Dictionary = {}):
	"""Ajoute un événement au journal"""
	var event = {
		"timestamp": Time.get_unix_time_from_system(),
		"datetime": Time.get_datetime_string_from_system(),
		"type": event_type,
		"data": data
	}
	
	events.append(event)
	
	# Limiter la taille
	while events.size() > MAX_EVENTS:
		events.pop_front()
	
	_save_events()

func update_world_state(key: String, value: Variant):
	"""Met à jour une valeur de l'état du monde"""
	world_state[key] = value
	_save_world_state()

func update_world_state_bulk(updates: Dictionary):
	"""Met à jour plusieurs valeurs de l'état du monde"""
	for key in updates:
		world_state[key] = updates[key]
	_save_world_state()

# === INDEXATION ===

func _rebuild_history_index():
	"""Reconstruit l'index de recherche"""
	history_index.clear()
	for i in range(history.size()):
		_index_history_entry(history[i], i)

func _index_history_entry(entry: Dictionary, index: int):
	"""Indexe une entrée d'historique"""
	var text = (entry.get("input", "") + " " + entry.get("response", "")).to_lower()
	var words = text.split(" ")
	
	for word in words:
		var cleaned = word.strip_edges()
		if cleaned.length() > 3:
			if not history_index.has(cleaned):
				history_index[cleaned] = []
			if index not in history_index[cleaned]:
				history_index[cleaned].append(index)

# === UTILITAIRES ===

func clear_history():
	"""Efface l'historique"""
	history.clear()
	history_index.clear()
	_save_history()

func clear_events():
	"""Efface les événements"""
	events.clear()
	_save_events()

func reset_world_state():
	"""Réinitialise l'état du monde"""
	world_state.clear()
	_save_world_state()

func get_full_history() -> Array:
	"""Retourne l'historique complet"""
	return history.duplicate()

func get_world_state() -> Dictionary:
	"""Retourne l'état du monde complet"""
	return world_state.duplicate()

func export_all_data() -> Dictionary:
	"""Exporte toutes les données pour sauvegarde externe"""
	return {
		"history": history,
		"world_state": world_state,
		"events": events,
		"exported_at": Time.get_datetime_string_from_system()
	}

func import_all_data(data: Dictionary):
	"""Importe des données depuis une sauvegarde externe"""
	if data.has("history"):
		history = data.history
		_rebuild_history_index()
	if data.has("world_state"):
		world_state = data.world_state
	if data.has("events"):
		events = data.events
	
	_save_history()
	_save_world_state()
	_save_events()
