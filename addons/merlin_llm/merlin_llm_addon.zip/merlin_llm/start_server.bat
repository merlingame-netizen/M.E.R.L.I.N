@echo off
REM ============================================
REM  Merlin AI - Démarrage serveur llama.cpp
REM  Pour Windows
REM ============================================

setlocal

REM === CONFIGURATION ===
REM Chemin vers llama.cpp (à modifier selon ton installation)
set LLAMA_CPP_PATH=C:\Users\PGNK2128\llama.cpp

REM Chemin vers les modèles
set MODELS_PATH=C:\Users\PGNK2128\Godot-MCP\addons\merlin_llm\models

REM Modèle à utiliser
set MODEL_FILE=qwen2.5-7b-instruct-q5_k_m.gguf

REM Configuration serveur
set HOST=127.0.0.1
set PORT=8080
set CONTEXT_SIZE=4096
set THREADS=8

REM GPU Layers (99 = tout sur GPU, 0 = CPU uniquement)
set GPU_LAYERS=99

REM === VÉRIFICATIONS ===
echo.
echo ============================================
echo   Merlin AI - Serveur LLM
echo ============================================
echo.

if not exist "%LLAMA_CPP_PATH%\llama-server.exe" (
    echo [ERREUR] llama-server.exe non trouve dans %LLAMA_CPP_PATH%
    echo.
    echo Verifie que llama.cpp est compile ou telecharge les binaires:
    echo https://github.com/ggerganov/llama.cpp/releases
    echo.
    pause
    exit /b 1
)

if not exist "%MODELS_PATH%\%MODEL_FILE%" (
    echo [ERREUR] Modele non trouve: %MODELS_PATH%\%MODEL_FILE%
    echo.
    echo Assure-toi d'avoir telecharge le modele GGUF.
    echo.
    pause
    exit /b 1
)

REM === DÉMARRAGE ===
echo [INFO] Chemin llama.cpp: %LLAMA_CPP_PATH%
echo [INFO] Modele: %MODEL_FILE%
echo [INFO] Serveur: http://%HOST%:%PORT%
echo [INFO] Contexte: %CONTEXT_SIZE% tokens
echo [INFO] GPU Layers: %GPU_LAYERS%
echo.
echo [INFO] Demarrage du serveur...
echo [INFO] Ctrl+C pour arreter
echo.
echo ============================================
echo.

"%LLAMA_CPP_PATH%\llama-server.exe" ^
    -m "%MODELS_PATH%\%MODEL_FILE%" ^
    --host %HOST% ^
    --port %PORT% ^
    -c %CONTEXT_SIZE% ^
    -ngl %GPU_LAYERS% ^
    --threads %THREADS%

echo.
echo [INFO] Serveur arrete.
pause
