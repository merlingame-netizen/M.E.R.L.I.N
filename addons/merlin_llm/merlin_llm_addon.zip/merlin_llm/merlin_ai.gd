extends Node
## Merlin AI - Singleton principal pour l'IA conversationnelle
## Utilise llama.cpp en local pour générer des réponses roleplay + actions

# === SIGNAUX ===
signal response_received(result: Dictionary)
signal action_executed(action: Dictionary)
signal error_occurred(message: String)
signal server_status_changed(is_connected: bool)

# === COMPOSANTS ===
var llm_client: LLMClient
var rag_manager: RAGManager
var action_validator: ActionValidator
var game_state_sync: GameStateSync

# === CONFIGURATION ===
const ADDON_PATH = "res://addons/merlin_llm/"
const MODELS_PATH = "C:/Users/PGNK2128/Godot-MCP/addons/merlin_llm/models/"

# URLs des serveurs llama.cpp
var server_url: String = "http://127.0.0.1:8080"
var router_server_url: String = "http://127.0.0.1:8081"  # Optionnel pour le routeur

# Utiliser un seul modèle pour tout (plus simple)
var use_single_model: bool = true

# Prompts et config
var prompts_config: Dictionary = {}
var actions_config: Dictionary = {}
var categories: Array = ["combat", "dialogue", "exploration", "inventaire", "magie", "quete"]

# État
var is_processing: bool = false
var is_server_connected: bool = false

func _ready():
	print("[MerlinAI] Initialisation...")
	
	# Créer les composants
	llm_client = LLMClient.new()
	llm_client.name = "LLMClient"
	add_child(llm_client)
	
	rag_manager = RAGManager.new()
	rag_manager.name = "RAGManager"
	add_child(rag_manager)
	
	action_validator = ActionValidator.new()
	action_validator.name = "ActionValidator"
	add_child(action_validator)
	
	game_state_sync = GameStateSync.new()
	game_state_sync.name = "GameStateSync"
	add_child(game_state_sync)
	
	# Connecter les signaux
	llm_client.request_completed.connect(_on_llm_response)
	llm_client.request_failed.connect(_on_llm_error)
	
	# Charger les configurations
	_load_configs()
	
	# Vérifier la connexion au serveur
	await get_tree().create_timer(1.0).timeout
	check_server_connection()
	
	print("[MerlinAI] Prêt !")

# === CONFIGURATION ===

func _load_configs():
	# Charger prompts.json
	var prompts_path = ADDON_PATH + "config/prompts.json"
	if FileAccess.file_exists(prompts_path):
		var file = FileAccess.open(prompts_path, FileAccess.READ)
		prompts_config = JSON.parse_string(file.get_as_text())
		file.close()
		print("[MerlinAI] Prompts chargés")
	else:
		_create_default_prompts()
	
	# Charger actions.json
	var actions_path = ADDON_PATH + "config/actions.json"
	if FileAccess.file_exists(actions_path):
		var file = FileAccess.open(actions_path, FileAccess.READ)
		actions_config = JSON.parse_string(file.get_as_text())
		file.close()
		print("[MerlinAI] Actions chargées")
	else:
		_create_default_actions()
	
	# Passer la config au validator
	action_validator.load_schema(actions_config)
	
	# Passer les actions au RAG manager par catégorie
	if actions_config.has("categories"):
		rag_manager.set_actions_by_category(actions_config.categories)

func _create_default_prompts():
	prompts_config = {
		"router_system": "Tu es un classificateur. Analyse l'input et réponds UNIQUEMENT par une catégorie parmi: combat, dialogue, exploration, inventaire, magie, quete. Rien d'autre.",
		"router_template": "<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\nInput: {input}\nCatégorie:<|im_end|>\n<|im_start|>assistant\n",
		"executor_system": """Tu es Merlin l'Enchanteur, sage conseiller aux connaissances mystiques. Tu parles de façon énigmatique mais bienveillante. Tu guides l'aventurier dans sa quête.

Réponds TOUJOURS au format JSON:
{
  "response": "Ta réponse roleplay ici",
  "action": {"type": "ACTION_ID", "params": {...}} ou null
}

Actions disponibles:
{actions}

Contexte actuel:
{context}

Historique récent:
{history}""",
		"executor_template": "<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{input}<|im_end|>\n<|im_start|>assistant\n"
	}
	_save_config("config/prompts.json", prompts_config)

func _create_default_actions():
	actions_config = {
		"categories": {
			"combat": {
				"ATTACK_MELEE": {"description": "Attaque au corps à corps", "params": ["target_id"], "conditions": ["target_in_range"]},
				"CAST_DAMAGE_SPELL": {"description": "Lance un sort offensif", "params": ["spell_id", "target_id"], "conditions": ["has_mana", "spell_known"]},
				"DEFEND": {"description": "Posture défensive", "params": [], "conditions": []}
			},
			"dialogue": {
				"REVEAL_INFO": {"description": "Révèle une information", "params": ["info_id"], "conditions": ["info_unlocked"]},
				"GIVE_QUEST": {"description": "Propose une quête", "params": ["quest_id"], "conditions": ["quest_available"]},
				"TRADE_OFFER": {"description": "Propose un échange", "params": ["item_offered", "item_requested"], "conditions": []}
			},
			"exploration": {
				"REVEAL_PATH": {"description": "Révèle un chemin caché", "params": ["path_id"], "conditions": []},
				"MARK_LOCATION": {"description": "Marque un lieu sur la carte", "params": ["location_id"], "conditions": []},
				"TRIGGER_EVENT": {"description": "Déclenche un événement", "params": ["event_id"], "conditions": ["event_available"]}
			},
			"inventaire": {
				"GIVE_ITEM": {"description": "Donne un objet au joueur", "params": ["item_id", "quantity"], "conditions": []},
				"TAKE_ITEM": {"description": "Prend un objet au joueur", "params": ["item_id", "quantity"], "conditions": ["item_in_inventory"]},
				"CRAFT_ITEM": {"description": "Fabrique un objet", "params": ["recipe_id"], "conditions": ["has_ingredients"]}
			},
			"magie": {
				"TEACH_SPELL": {"description": "Enseigne un sort", "params": ["spell_id"], "conditions": ["player_level_sufficient"]},
				"ENCHANT_ITEM": {"description": "Enchante un objet", "params": ["item_id", "enchant_type"], "conditions": ["item_in_inventory"]},
				"SUMMON_CREATURE": {"description": "Invoque une créature", "params": ["creature_id", "location"], "conditions": ["has_mana"]}
			},
			"quete": {
				"START_QUEST": {"description": "Démarre une quête", "params": ["quest_id"], "conditions": ["quest_available"]},
				"UPDATE_QUEST": {"description": "Met à jour une quête", "params": ["quest_id", "step"], "conditions": ["quest_active"]},
				"COMPLETE_QUEST": {"description": "Termine une quête", "params": ["quest_id"], "conditions": ["quest_objectives_done"]}
			}
		}
	}
	_save_config("config/actions.json", actions_config)

func _save_config(relative_path: String, data: Dictionary):
	var full_path = ADDON_PATH + relative_path
	var dir_path = full_path.get_base_dir()
	
	# Créer le dossier si nécessaire
	if not DirAccess.dir_exists_absolute(dir_path):
		DirAccess.make_dir_recursive_absolute(dir_path)
	
	var file = FileAccess.open(full_path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data, "\t"))
		file.close()

# === MÉTHODE PRINCIPALE ===

func process_player_input(input_text: String) -> void:
	"""Traite l'input du joueur et génère une réponse de Merlin"""
	if is_processing:
		error_occurred.emit("Déjà en cours de traitement")
		return
	
	if not is_server_connected:
		error_occurred.emit("Serveur LLM non connecté")
		return
	
	is_processing = true
	print("[MerlinAI] Traitement: ", input_text.substr(0, 50), "...")
	
	# Étape 1 : Routage (déterminer la catégorie)
	var category = await _route_input(input_text)
	print("[MerlinAI] Catégorie détectée: ", category)
	
	# Étape 2 : Récupérer le contexte RAG
	var context = rag_manager.get_relevant_context(input_text, category)
	
	# Étape 3 : Générer la réponse avec le contexte
	var result = await _execute_with_context(input_text, context, category)
	
	if result.is_empty():
		is_processing = false
		error_occurred.emit("Échec de génération de réponse")
		return
	
	# Étape 4 : Valider et exécuter l'action
	if result.has("action") and result.action != null:
		var validation = action_validator.validate(result.action)
		if validation.valid:
			game_state_sync.apply_action(result.action)
			action_executed.emit(result.action)
			print("[MerlinAI] Action exécutée: ", result.action.type)
		else:
			print("[MerlinAI] Action invalide: ", validation.errors)
			result["action_errors"] = validation.errors
	
	# Étape 5 : Sauvegarder dans l'historique
	rag_manager.add_to_history(input_text, result.get("response", ""))
	
	is_processing = false
	response_received.emit(result)

# === ROUTAGE ===

func _route_input(input_text: String) -> String:
	"""Détermine la catégorie de l'input (combat, dialogue, etc.)"""
	if use_single_model:
		# Utiliser le même serveur pour le routage
		var prompt = _build_router_prompt(input_text)
		var response = await llm_client.complete_async(server_url, prompt, 20)
		return _parse_category(response)
	else:
		# Utiliser un serveur dédié au routage
		var prompt = _build_router_prompt(input_text)
		var response = await llm_client.complete_async(router_server_url, prompt, 20)
		return _parse_category(response)

func _build_router_prompt(input_text: String) -> String:
	var system = prompts_config.get("router_system", "Classifie en: combat, dialogue, exploration, inventaire, magie, quete")
	var template = prompts_config.get("router_template", "<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{input}<|im_end|>\n<|im_start|>assistant\n")
	
	return template.replace("{system}", system).replace("{input}", input_text)

func _parse_category(response: String) -> String:
	"""Extrait la catégorie de la réponse du routeur"""
	var cleaned = response.strip_edges().to_lower()
	
	for cat in categories:
		if cleaned.contains(cat):
			return cat
	
	# Par défaut
	return "dialogue"

# === EXÉCUTION ===

func _execute_with_context(input_text: String, context: Dictionary, category: String) -> Dictionary:
	"""Génère la réponse de Merlin avec le contexte"""
	var prompt = _build_executor_prompt(input_text, context, category)
	var response = await llm_client.complete_async(server_url, prompt, 500)
	
	return _parse_executor_response(response)

func _build_executor_prompt(input_text: String, context: Dictionary, category: String) -> String:
	var system_template = prompts_config.get("executor_system", "Tu es Merlin.")
	
	# Formater les actions disponibles
	var actions_text = _format_actions_for_prompt(category)
	
	# Formater le contexte
	var context_text = _format_context_for_prompt(context)
	
	# Formater l'historique
	var history_text = _format_history_for_prompt(context.get("recent_history", []))
	
	# Remplacer les placeholders
	var system = system_template.replace("{actions}", actions_text).replace("{context}", context_text).replace("{history}", history_text)
	
	var template = prompts_config.get("executor_template", "<|im_start|>system\n{system}<|im_end|>\n<|im_start|>user\n{input}<|im_end|>\n<|im_start|>assistant\n")
	
	return template.replace("{system}", system).replace("{input}", input_text)

func _format_actions_for_prompt(category: String) -> String:
	var actions = rag_manager.get_actions_for_category(category)
	if actions.is_empty():
		return "Aucune action spécifique disponible."
	
	var lines = []
	for action_id in actions:
		var action = actions[action_id]
		var params_str = ", ".join(action.get("params", []))
		lines.append("- %s: %s (params: %s)" % [action_id, action.get("description", ""), params_str])
	
	return "\n".join(lines)

func _format_context_for_prompt(context: Dictionary) -> String:
	var world_state = context.get("world_state_subset", {})
	if world_state.is_empty():
		return "Pas de contexte spécifique."
	
	return JSON.stringify(world_state)

func _format_history_for_prompt(history: Array) -> String:
	if history.is_empty():
		return "Première interaction."
	
	var lines = []
	for item in history:
		lines.append("Joueur: %s\nMerlin: %s" % [item.get("input", ""), item.get("response", "")])
	
	return "\n---\n".join(lines)

func _parse_executor_response(response: String) -> Dictionary:
	"""Parse la réponse JSON de l'exécuteur"""
	var cleaned = response.strip_edges()
	
	# Chercher le JSON dans la réponse
	var json_start = cleaned.find("{")
	var json_end = cleaned.rfind("}") + 1
	
	if json_start == -1 or json_end <= json_start:
		# Pas de JSON trouvé, retourner la réponse brute
		return {"response": cleaned, "action": null}
	
	var json_str = cleaned.substr(json_start, json_end - json_start)
	
	var parsed = JSON.parse_string(json_str)
	if parsed == null:
		return {"response": cleaned, "action": null}
	
	return parsed

# === UTILITAIRES ===

func check_server_connection() -> void:
	"""Vérifie si le serveur llama.cpp est accessible"""
	var result = await llm_client.check_health(server_url)
	is_server_connected = result
	server_status_changed.emit(is_server_connected)
	
	if is_server_connected:
		print("[MerlinAI] Connecté au serveur: ", server_url)
	else:
		print("[MerlinAI] ERREUR: Serveur non accessible: ", server_url)

func set_server_url(url: String) -> void:
	server_url = url
	check_server_connection()

func get_game_state() -> Dictionary:
	return game_state_sync.get_state()

func update_game_state(key: String, value: Variant) -> void:
	game_state_sync.update_state(key, value)
	rag_manager.update_world_state(key, value)

func _on_llm_response(response: String):
	pass  # Géré dans les awaits

func _on_llm_error(error: String):
	error_occurred.emit(error)
