extends Node
class_name ActionValidator
## Validateur d'actions générées par le LLM
## Vérifie que les actions sont valides avant exécution

signal validation_failed(action: Dictionary, errors: Array)
signal validation_passed(action: Dictionary)

# Schéma des actions (chargé depuis config)
var actions_schema: Dictionary = {}

# Référence à l'état du jeu (lecture seule)
var game_state: Dictionary = {}

# Conditions personnalisées (callbacks)
var custom_conditions: Dictionary = {}

func _ready():
	pass

# === CHARGEMENT DU SCHÉMA ===

func load_schema(config: Dictionary):
	"""Charge le schéma des actions depuis la config"""
	if config.has("categories"):
		# Aplatir les catégories en un seul dictionnaire
		actions_schema.clear()
		for category in config.categories:
			var actions = config.categories[category]
			for action_id in actions:
				actions_schema[action_id] = actions[action_id]
				actions_schema[action_id]["category"] = category
		print("[ActionValidator] Schéma chargé: ", actions_schema.size(), " actions")

func set_game_state(state: Dictionary):
	"""Met à jour la référence à l'état du jeu"""
	game_state = state

# === VALIDATION ===

func validate(action: Dictionary) -> Dictionary:
	"""Valide une action et retourne le résultat"""
	var result = {
		"valid": false,
		"errors": [],
		"warnings": []
	}
	
	# Vérifier la structure de base
	if not action.has("type"):
		result.errors.append("Action manquante: champ 'type' requis")
		validation_failed.emit(action, result.errors)
		return result
	
	var action_type = action.type
	
	# Vérifier si l'action existe dans le schéma
	if not actions_schema.has(action_type):
		result.errors.append("Action inconnue: " + action_type)
		validation_failed.emit(action, result.errors)
		return result
	
	var schema = actions_schema[action_type]
	
	# Vérifier les paramètres requis
	var param_errors = _validate_params(action, schema)
	result.errors.append_array(param_errors)
	
	# Vérifier les conditions
	var condition_errors = _validate_conditions(action, schema)
	result.errors.append_array(condition_errors)
	
	# Déterminer si valide
	result.valid = result.errors.is_empty()
	
	if result.valid:
		validation_passed.emit(action)
	else:
		validation_failed.emit(action, result.errors)
	
	return result

func _validate_params(action: Dictionary, schema: Dictionary) -> Array:
	"""Vérifie que tous les paramètres requis sont présents"""
	var errors: Array = []
	
	if not schema.has("params"):
		return errors
	
	var required_params = schema.params
	var provided_params = action.get("params", {})
	
	for param in required_params:
		if not provided_params.has(param):
			errors.append("Paramètre manquant: " + param)
		elif provided_params[param] == null or provided_params[param] == "":
			errors.append("Paramètre vide: " + param)
	
	return errors

func _validate_conditions(action: Dictionary, schema: Dictionary) -> Array:
	"""Vérifie que toutes les conditions sont remplies"""
	var errors: Array = []
	
	if not schema.has("conditions"):
		return errors
	
	for condition in schema.conditions:
		if not _check_condition(condition, action):
			errors.append("Condition non remplie: " + condition)
	
	return errors

func _check_condition(condition: String, action: Dictionary) -> bool:
	"""Vérifie une condition spécifique"""
	# D'abord vérifier les conditions personnalisées
	if custom_conditions.has(condition):
		return custom_conditions[condition].call(action, game_state)
	
	# Ensuite les conditions intégrées
	var params = action.get("params", {})
	
	match condition:
		"target_in_range":
			return _check_target_in_range(params.get("target_id", ""))
		"has_mana":
			return _check_has_mana(params.get("mana_cost", 10))
		"spell_known":
			return _check_spell_known(params.get("spell_id", ""))
		"item_in_inventory":
			return _check_item_in_inventory(params.get("item_id", ""))
		"has_ingredients":
			return _check_has_ingredients(params.get("recipe_id", ""))
		"quest_available":
			return _check_quest_available(params.get("quest_id", ""))
		"quest_active":
			return _check_quest_active(params.get("quest_id", ""))
		"quest_objectives_done":
			return _check_quest_objectives_done(params.get("quest_id", ""))
		"info_unlocked":
			return _check_info_unlocked(params.get("info_id", ""))
		"event_available":
			return _check_event_available(params.get("event_id", ""))
		"player_level_sufficient":
			return _check_player_level(params.get("required_level", 1))
		_:
			# Condition inconnue = on laisse passer avec un warning
			push_warning("[ActionValidator] Condition inconnue: " + condition)
			return true

# === CONDITIONS INTÉGRÉES ===

func _check_target_in_range(target_id: String) -> bool:
	if target_id.is_empty():
		return false
	var targets_in_range = game_state.get("targets_in_range", [])
	return target_id in targets_in_range

func _check_has_mana(cost: int) -> bool:
	var current_mana = game_state.get("player_mana", 0)
	return current_mana >= cost

func _check_spell_known(spell_id: String) -> bool:
	if spell_id.is_empty():
		return false
	var known_spells = game_state.get("known_spells", [])
	return spell_id in known_spells

func _check_item_in_inventory(item_id: String) -> bool:
	if item_id.is_empty():
		return false
	var inventory = game_state.get("inventory", {})
	return inventory.has(item_id) and inventory[item_id] > 0

func _check_has_ingredients(recipe_id: String) -> bool:
	# TODO: Implémenter selon ton système de craft
	return true

func _check_quest_available(quest_id: String) -> bool:
	if quest_id.is_empty():
		return false
	var available_quests = game_state.get("available_quests", [])
	var active_quests = game_state.get("active_quests", [])
	var completed_quests = game_state.get("completed_quests", [])
	return quest_id in available_quests and quest_id not in active_quests and quest_id not in completed_quests

func _check_quest_active(quest_id: String) -> bool:
	if quest_id.is_empty():
		return false
	var active_quests = game_state.get("active_quests", [])
	return quest_id in active_quests

func _check_quest_objectives_done(quest_id: String) -> bool:
	if quest_id.is_empty():
		return false
	var quest_progress = game_state.get("quest_progress", {})
	if not quest_progress.has(quest_id):
		return false
	return quest_progress[quest_id].get("objectives_completed", false)

func _check_info_unlocked(info_id: String) -> bool:
	if info_id.is_empty():
		return false
	var unlocked_info = game_state.get("unlocked_info", [])
	return info_id in unlocked_info

func _check_event_available(event_id: String) -> bool:
	if event_id.is_empty():
		return false
	var available_events = game_state.get("available_events", [])
	var triggered_events = game_state.get("triggered_events", [])
	return event_id in available_events and event_id not in triggered_events

func _check_player_level(required_level: int) -> bool:
	var player_level = game_state.get("player_level", 1)
	return player_level >= required_level

# === CONDITIONS PERSONNALISÉES ===

func register_condition(condition_name: String, callback: Callable):
	"""Enregistre une condition personnalisée
	Le callback reçoit (action: Dictionary, game_state: Dictionary) -> bool"""
	custom_conditions[condition_name] = callback

func unregister_condition(condition_name: String):
	"""Supprime une condition personnalisée"""
	custom_conditions.erase(condition_name)

# === UTILITAIRES ===

func get_action_schema(action_type: String) -> Dictionary:
	"""Retourne le schéma d'une action"""
	return actions_schema.get(action_type, {})

func get_all_action_types() -> Array:
	"""Retourne la liste de tous les types d'actions"""
	return actions_schema.keys()

func get_actions_by_category(category: String) -> Array:
	"""Retourne les actions d'une catégorie"""
	var result: Array = []
	for action_type in actions_schema:
		if actions_schema[action_type].get("category", "") == category:
			result.append(action_type)
	return result
