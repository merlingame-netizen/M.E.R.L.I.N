@tool
extends EditorPlugin

const AUTOLOAD_NAME = "MerlinAI"

func _enter_tree():
	# Ajouter le singleton MerlinAI
	add_autoload_singleton(AUTOLOAD_NAME, "res://addons/merlin_llm/merlin_ai.gd")
	print("[Merlin LLM] Plugin activé")

func _exit_tree():
	# Retirer le singleton
	remove_autoload_singleton(AUTOLOAD_NAME)
	print("[Merlin LLM] Plugin désactivé")
