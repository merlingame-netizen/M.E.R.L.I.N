# 🧙 Merlin LLM - Addon Godot 4

Système d'IA conversationnelle avec LLM local (llama.cpp) pour jeux Godot.

## 📋 Fonctionnalités

- **Personnage IA roleplay** : Merlin l'Enchanteur répond en personnage
- **Actions contextuelles** : Le LLM peut déclencher des actions dans le jeu
- **Mémoire persistante** : RAG pour retenir les conversations et l'état du monde
- **Validation des actions** : Vérifie que les actions sont valides avant exécution
- **100% local** : Aucune API cloud, tout fonctionne sur ta machine

## 🚀 Installation

### 1. Prérequis

- **Godot 4.x**
- **llama.cpp** compilé ou binaires téléchargés
- **Modèle GGUF** : Qwen 2.5 7B Instruct (recommandé)

### 2. Installer l'addon

1. Copie le dossier `merlin_llm` dans `addons/` de ton projet Godot
2. Dans Godot : **Projet → Paramètres du projet → Extensions**
3. Active **Merlin LLM**

### 3. Télécharger le modèle

Télécharge `qwen2.5-7b-instruct-q5_k_m.gguf` depuis :
https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF

Place-le dans : `addons/merlin_llm/models/`

### 4. Installer llama.cpp

**Option A - Binaires pré-compilés :**
https://github.com/ggerganov/llama.cpp/releases

**Option B - Compiler :**
```bash
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

### 5. Configurer les chemins

Édite `merlin_ai.gd` ligne 15 :
```gdscript
const MODELS_PATH = "C:/ton/chemin/vers/models/"
```

Édite `start_server.bat` :
```batch
set LLAMA_CPP_PATH=C:\ton\chemin\vers\llama.cpp
set MODELS_PATH=C:\ton\chemin\vers\models
```

## 🎮 Utilisation

### Démarrer le serveur LLM

Double-clique sur `start_server.bat` **AVANT** de lancer Godot.

### Dans ton code

```gdscript
# Envoyer un message à Merlin
MerlinAI.process_player_input("Bonjour Merlin, que dois-je faire ?")

# Écouter la réponse
MerlinAI.response_received.connect(func(result):
    print("Merlin dit: ", result.response)
)

# Écouter les actions
MerlinAI.action_executed.connect(func(action):
    print("Action: ", action.type)
)

# Mettre à jour l'état du jeu
MerlinAI.update_game_state("player_level", 5)
MerlinAI.update_game_state("current_location", "foret")
```

### Scène d'exemple

Ouvre `example_dialog.tscn` pour voir un exemple complet.

## 📁 Structure des fichiers

```
addons/merlin_llm/
├── plugin.cfg              # Config du plugin
├── merlin_plugin.gd        # Activation du plugin
├── merlin_ai.gd            # Singleton principal (Autoload)
├── llm_client.gd           # Communication HTTP
├── rag_manager.gd          # Gestion mémoire/RAG
├── action_validator.gd     # Validation actions
├── game_state_sync.gd      # Sync état du jeu
├── example_dialog.gd       # Script exemple
├── example_dialog.tscn     # Scène exemple
├── start_server.bat        # Démarrage serveur Windows
├── config/
│   ├── prompts.json        # Prompts système
│   └── actions.json        # Définition des actions
├── models/                 # Tes fichiers .gguf ici
└── memory/                 # Données sauvegardées (auto)
```

## ⚙️ Configuration

### Ajouter de nouvelles actions

Édite `config/actions.json` :

```json
{
  "categories": {
    "ma_categorie": {
      "MON_ACTION": {
        "description": "Description de l'action",
        "params": ["param1", "param2"],
        "conditions": ["condition1"]
      }
    }
  }
}
```

### Personnaliser Merlin

Édite `config/prompts.json` pour modifier la personnalité.

### Conditions personnalisées

```gdscript
# Dans ton code
MerlinAI.action_validator.register_condition("ma_condition", func(action, state):
    return state.get("ma_variable", false)
)
```

### Handlers d'actions personnalisés

```gdscript
# Gérer une action spécifique
MerlinAI.game_state_sync.register_action_handler("MON_ACTION", func(action, state):
    # Ta logique ici
    return {"success": true}
)
```

## 🔧 API

### Signaux MerlinAI

| Signal | Arguments | Description |
|--------|-----------|-------------|
| `response_received` | `result: Dictionary` | Réponse de Merlin reçue |
| `action_executed` | `action: Dictionary` | Action exécutée |
| `error_occurred` | `message: String` | Erreur survenue |
| `server_status_changed` | `is_connected: bool` | Statut serveur changé |

### Méthodes MerlinAI

| Méthode | Description |
|---------|-------------|
| `process_player_input(text)` | Envoie un message à Merlin |
| `update_game_state(key, value)` | Met à jour l'état du jeu |
| `check_server_connection()` | Vérifie la connexion |
| `set_server_url(url)` | Change l'URL du serveur |

## ❓ Dépannage

### "Serveur non connecté"

1. Vérifie que `start_server.bat` est lancé
2. Vérifie les chemins dans le script
3. Attends 30-60s que le modèle se charge

### Réponses lentes

- **GPU** : Assure-toi que `-ngl 99` est dans le script (utilise le GPU)
- **CPU** : Normal, compte 30-60s par réponse
- **RAM** : Le modèle 7B nécessite ~6 Go de RAM

### Le modèle ne charge pas

- Vérifie que le fichier `.gguf` n'est pas corrompu
- Essaie un modèle plus petit (Q4 au lieu de Q5)

## 📝 Licence

MIT - Utilise librement dans tes projets !
